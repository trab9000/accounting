<?php
/*
 $Rev: 384 $ | $LastChangedBy: brieb $
 $LastChangedDate: 2008-05-04 17:18:08 -0600 (Sun, 04 May 2008) $
 +-------------------------------------------------------------------------+
 | Copyright (c) 2004 - 2007, Kreotek LLC                                  |
 | All rights reserved.                                                    |
 +-------------------------------------------------------------------------+
 |                                                                         |
 | Redistribution and use in source and binary forms, with or without      |
 | modification, are permitted provided that the following conditions are  |
 | met:                                                                    |
 |                                                                         |
 | - Redistributions of source code must retain the above copyright        |
 |   notice, this list of conditions and the following disclaimer.         |
 |                                                                         |
 | - Redistributions in binary form must reproduce the above copyright     |
 |   notice, this list of conditions and the following disclaimer in the   |
 |   documentation and/or other materials provided with the distribution.  |
 |                                                                         |
 | - Neither the name of Kreotek LLC nor the names of its contributore may |
 |   be used to endorse or promote products derived from this software     |
 |   without specific prior written permission.                            |
 |                                                                         |
 | THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS     |
 | "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       |
 | LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A |
 | PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT      |
 | OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,   |
 | SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT        |
 | LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,   |
 | DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY   |
 | THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT     |
 | (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE   |
 | OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    |
 |                                                                         |
 +-------------------------------------------------------------------------+
*/

	if($_SESSION["printing"]["sortorder"])
		$sortorder=$_SESSION["printing"]["sortorder"];
	else
		$sortorder="  ORDER BY invoices.orderdate";

	$maxrows=10;
	$maxcolumns=3;
	$topstart=1/2;
	$leftstart=3/16;
	$columnmargin=1/8;
	$labelheight=1;
	$labelwidth=2+(5/8);
	
	$reportquerystatement="
		SELECT
			clients.firstname,
			clients.lastname,
			clients.company,
			invoices.address1,
			invoices.address2,
			invoices.city,
			invoices.state,
			invoices.postalcode,
			invoices.country,
			invoices.shiptosameasbilling,
			invoices.shiptoname,
			invoices.shiptoaddress1,
			invoices.shiptoaddress2,
			invoices.shiptocity,
			invoices.shiptostate,
			invoices.shiptopostalcode,
			invoices.shiptocountry
		FROM 
			invoices INNER JOIN clients on invoices.clientid=clients.id 
		";
						
	$border_debug=0;

	function printLabel($pdf,$therecord,$thex,$they,$border_debug){
		//offset lef tby 1/8" and top by 1/16th
		$pdf->SetXY($thex+(1/8),$they+1/16);
		$pdf->SetFont("Arial","B",9);

		$thename = $therecord["company"];
		if($thename)
			$thename .= "\n";
		$thename .= trim($therecord["firstname"]." ".$therecord["lastname"]);
		
		if(!$therecord["shiptosameasbilling"] && !!$therecord["shiptoname"])
			$thename = $therecord["shiptoname"];

		$pdf->MultiCell(2.25,.135,$thename,$border_debug,2,"L");
		$pdf->SetFont("Arial","",8);
		$pdf->SetX($thex+(1/8));
		
		if(!$therecord["shiptosameasbilling"]){
			
			$therecord["address1"] = $therecord["shiptoaddress1"];
			$therecord["address2"] = $therecord["shiptoaddress2"];
			$therecord["city"] = $therecord["shiptocity"];
			$therecord["state"] = $therecord["shiptostate"];
			$therecord["postalcode"] = $therecord["shiptopostalcode"];
			$therecord["country"] = $therecord["shiptocountry"];
			
		}//endif - shiptosameasbilling
		
		$pdf->Cell(2.25,.12,$therecord["address1"],$border_debug,2,"L");
		if($therecord["address2"]) $pdf->Cell(2.25,.12,$therecord["address2"],$border_debug,2,"L");
		$pdf->Cell(2.25,.12,$therecord["city"].", ".$therecord["state"]." ".$therecord["postalcode"],$border_debug,2,"L");
		if($therecord["country"]) $pdf->Cell(2.25,.12,$therecord["country"],$border_debug,2,"L");
		
		return $pdf;
	}

	session_cache_limiter('private');	
	require_once("../../../include/session.php");		
	require_once("../../../fpdf/fpdf.php");
	require("../../../report/general_labels.php");	
?>