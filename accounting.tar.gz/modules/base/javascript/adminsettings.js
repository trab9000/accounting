/*
 $Rev: 290 $ | $LastChangedBy: brieb $
 $LastChangedDate: 2007-08-27 18:15:00 -0600 (Mon, 27 Aug 2007) $
 +-------------------------------------------------------------------------+
 | Copyright (c) 2004 - 2007, Kreotek LLC                                  |
 | All rights reserved.                                                    |
 +-------------------------------------------------------------------------+
 |                                                                         |
 | Redistribution and use in source and binary forms, with or without      |
 | modification, are permitted provided that the following conditions are  |
 | met:                                                                    |
 |                                                                         |
 | - Redistributions of source code must retain the above copyright        |
 |   notice, this list of conditions and the following disclaimer.         |
 |                                                                         |
 | - Redistributions in binary form must reproduce the above copyright     |
 |   notice, this list of conditions and the following disclaimer in the   |
 |   documentation and/or other materials provided with the distribution.  |
 |                                                                         |
 | - Neither the name of Kreotek LLC nor the names of its contributore may |
 |   be used to endorse or promote products derived from this software     |
 |   without specific prior written permission.                            |
 |                                                                         |
 | THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS     |
 | "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       |
 | LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A |
 | PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT      |
 | OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,   |
 | SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT        |
 | LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,   |
 | DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY   |
 | THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT     |
 | (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE   |
 | OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    |
 |                                                                         |
 +-------------------------------------------------------------------------+
*/

function toggleEncryptionEdit(seedcheck){
	var seedinput=getObjectFromID("encryption_seed");
	var currpassinput=getObjectFromID("currentpassword");
	var updatebutton=getObjectFromID("updateSettings3");
	if (seedcheck.checked){
		seedinput.removeAttribute("readOnly");
		currpassinput.removeAttribute("readOnly");
		updatebutton.disabled=false;
		seedinput.className="";
		currpassinput.className="";
		seedinput.focus();
	} else {
		updatebutton.disabled=true;
		seedinput.setAttribute("readOnly","readonly");		
		currpassinput.setAttribute("readOnly","readonly");		
		seedinput.className="uneditable";
		currpassinput.className="uneditable";
	}
}

function setEncryptionUpdate(){
	var doencryptionupdate = getObjectFromID("doencryptionupdate")
	doencryptionupdate.value = 1;
}

function processForm(theform){
	var changeseed=getObjectFromID("changeseed");
	var $thereturn=false;
	var doencryptionupdate = getObjectFromID("doencryptionupdate")
	
	if(changeseed.checked && doencryptionupdate.value!=1)
		alert("Encryption Seed Must be updated separately from other settings.");
	else {
		if(doencryptionupdate.value==1){
			var seedinput=getObjectFromID("encryption_seed");
			if(seedinput.value==""){
				alert("Encryption seed cannot be blank.");
				$thereturn=false;
			}
			else
			$thereturn=true;
		}
		else{
			$thereturn=validateForm(theform);
		}
	} 
	return $thereturn;
}