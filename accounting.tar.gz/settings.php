<?php /* ]
mysql_server	= "localhost"
mysql_database	= "fncinc01_phpbms"
mysql_user		= "fncinc01_weberp"
mysql_userpass	= "chacha12!"
mysql_pconnect	= "true"
 end] */ ?>